/*!
 * Call Center widget loader (standalone, independent from chat widget).
 * Embed:
 *   <script async src="https://YOUR_DOMAIN/call-widget/l.js"
 *           workspace-id="WS_ID"></script>
 * Or with a public key:
 *   <script async src="https://YOUR_DOMAIN/call-widget/l.js"
 *           public-key="cck_..."></script>
 */
(function () {
  'use strict';
  if (window.__CC_WIDGET_LOADED__) return;
  window.__CC_WIDGET_LOADED__ = true;

  var s = document.currentScript || (function () {
    var arr = document.getElementsByTagName('script');
    return arr[arr.length - 1];
  })();
  var src = s.src || '';
  var origin = '';
  try { origin = new URL(src).origin; } catch (_) { origin = window.location.origin; }

  var workspaceId = s.getAttribute('workspace-id') || s.getAttribute('data-workspace-id');
  var publicKey = s.getAttribute('public-key') || s.getAttribute('data-public-key');
  if (!workspaceId && !publicKey) {
    console.warn('[call-widget] missing workspace-id or public-key');
    return;
  }

  var apiBase = (s.getAttribute('api-base') || origin).replace(/\/$/, '');

  var qs = workspaceId
    ? 'workspaceId=' + encodeURIComponent(workspaceId)
    : 'publicKey=' + encodeURIComponent(publicKey);

  fetch(apiBase + '/api/call-widget/bootstrap?' + qs, {
    credentials: 'omit',
    headers: { 'Accept': 'application/json' },
  })
    .then(function (r) { return r.json().then(function (j) { return { ok: r.ok, status: r.status, body: j }; }); })
    .then(function (resp) {
      if (!resp.ok || resp.body.status !== 'ok') {
        if (resp.body && resp.body.status === 'disabled') return; // silent: globally disabled
        console.warn('[call-widget] bootstrap failed', resp);
        return;
      }
      var bootstrap = resp.body;
      // Inject CSS
      var link = document.createElement('link');
      link.rel = 'stylesheet';
      link.href = origin + '/call-widget/runtime.css';
      document.head.appendChild(link);

      // Load the LiveKit SDK locally if the host page hasn't provided one.
      // We reuse the SDK file shipped alongside the chat widget so customers
      // only paste a single call-widget script tag — no external CDN.
      function loadRuntime() {
        var sc = document.createElement('script');
        sc.async = true;
        sc.src = origin + '/call-widget/runtime.js';
        sc.onload = function () {
          if (window.CallCenterWidget && typeof window.CallCenterWidget.mount === 'function') {
            window.CallCenterWidget.mount({
              apiBase: apiBase,
              origin: origin,
              bootstrap: bootstrap,
            });
          }
        };
        document.body.appendChild(sc);
      }

      function ensureLiveKitSdk(cb) {
        if (window.LivekitClient || window.LiveKit) return cb();
        // Idempotent: avoid double-injection if another widget instance is loading.
        var existing = document.querySelector('script[data-cc-livekit-sdk]');
        if (existing) {
          existing.addEventListener('load', cb);
          existing.addEventListener('error', cb); // runtime will surface media_client_missing
          return;
        }
        var lk = document.createElement('script');
        lk.async = true;
        lk.setAttribute('data-cc-livekit-sdk', '1');
        // Local asset only — never an external CDN.
        lk.src = origin + '/widget/vendor/livekit-client.umd.min.js';
        lk.onload = cb;
        lk.onerror = cb; // runtime will detect missing window.LivekitClient and show media_client_missing
        document.head.appendChild(lk);
      }

      ensureLiveKitSdk(loadRuntime);
    })
    .catch(function (err) {
      console.warn('[call-widget] bootstrap error', err);
    });
})();