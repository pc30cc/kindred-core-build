/**
 * ACCOUNT ROUTES — self-service for the currently authenticated user.
 *
 * Auth: Supabase access token (Bearer) — verified via service client.
 * Storage: avatars are uploaded through the active workspace storage
 *   provider (BunnyCDN / S3 / local) using the existing storage service,
 *   so secrets never reach the browser.
 * Object key convention: `avatars/<userId>/<timestamp>-<rand>.<ext>`
 *
 * Backward compatibility: this router is purely additive; existing
 * profile reads via Supabase RLS continue to work.
 */

import { Router } from 'express';
import { z } from 'zod';
import crypto from 'crypto';
import type { ServerConfig } from '../config.js';
import { getServiceClient } from '../supabase.js';
import { uploadFile, deleteFile } from '../services/storage/index.js';
import { resolveVisitorGeo } from '../services/geo/index.js';
import { hashIp, maskIp } from '../utils/clientIp.js';

export const accountRouter = Router();

// ── Auth middleware ───────────────────────────────────────────────
async function requireUser(req: any, res: any, next: any) {
  const config: ServerConfig = req.serverConfig;
  const authHeader = req.headers.authorization;
  if (!authHeader?.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Missing authorization' });
  }
  const token = authHeader.slice(7);
  const sb = getServiceClient(config);
  const { data, error } = await sb.auth.getUser(token);
  if (error || !data?.user) {
    return res.status(401).json({ error: 'Invalid token' });
  }
  req.authUser = data.user;
  next();
}

accountRouter.use(requireUser);

// ── Helper: get user's primary workspace for storage scoping ──────
async function getUserPrimaryWorkspaceId(config: ServerConfig, userId: string): Promise<string | null> {
  const sb = getServiceClient(config);
  const { data } = await sb
    .from('workspace_members')
    .select('workspace_id, created_at')
    .eq('user_id', userId)
    .order('created_at', { ascending: true })
    .limit(1)
    .maybeSingle();
  return data?.workspace_id ?? null;
}

// ── GET /api/account/me ───────────────────────────────────────────
accountRouter.get('/me', async (req, res) => {
  try {
    const config: ServerConfig = (req as any).serverConfig;
    const user = (req as any).authUser;
    const sb = getServiceClient(config);

    const { data: profile } = await sb
      .from('profiles')
      .select('*')
      .eq('id', user.id)
      .maybeSingle();

    return res.json({
      id: user.id,
      email: user.email,
      email_confirmed_at: user.email_confirmed_at ?? null,
      phone: user.phone ?? null,
      created_at: user.created_at,
      profile: profile ?? null,
    });
  } catch (err: any) {
    return res.status(500).json({ error: err?.message || 'Failed to load account' });
  }
});

// ── PATCH /api/account/me ─────────────────────────────────────────
const updateProfileSchema = z.object({
  full_name: z.string().trim().max(120).nullable().optional(),
  first_name: z.string().trim().max(60).optional(),
  last_name: z.string().trim().max(60).optional(),
  preferred_locale: z.string().trim().min(2).max(10).nullable().optional(),
  company_name: z.string().trim().max(120).nullable().optional(),
  website_domain: z.string().trim().max(255).nullable().optional(),
  phone: z.string().trim().max(40).nullable().optional(),
});

accountRouter.patch('/me', async (req, res) => {
  try {
    const config: ServerConfig = (req as any).serverConfig;
    const user = (req as any).authUser;
    const parsed = updateProfileSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: 'Invalid input', details: parsed.error.flatten().fieldErrors });
    }
    const sb = getServiceClient(config);

    // Compose full_name from first/last if provided explicitly
    const updates: Record<string, unknown> = {};
    if (parsed.data.first_name !== undefined || parsed.data.last_name !== undefined) {
      const first = (parsed.data.first_name ?? '').trim();
      const last = (parsed.data.last_name ?? '').trim();
      const combined = [first, last].filter(Boolean).join(' ').trim();
      if (combined) updates.full_name = combined;
    }
    for (const k of ['full_name', 'preferred_locale', 'company_name', 'website_domain'] as const) {
      if (parsed.data[k] !== undefined) updates[k] = parsed.data[k];
    }

    if (Object.keys(updates).length > 0) {
      updates.updated_at = new Date().toISOString();
      const { error: profileErr } = await sb
        .from('profiles')
        .update(updates)
        .eq('id', user.id);
      if (profileErr) {
        return res.status(500).json({ error: profileErr.message });
      }
    }

    // Phone is on auth.users — propagate via admin API
    if (parsed.data.phone !== undefined) {
      const { error: authErr } = await sb.auth.admin.updateUserById(user.id, {
        phone: parsed.data.phone || undefined,
      });
      if (authErr) {
        return res.status(400).json({ error: authErr.message });
      }
    }

    const { data: profile } = await sb
      .from('profiles')
      .select('*')
      .eq('id', user.id)
      .maybeSingle();

    return res.json({ success: true, profile });
  } catch (err: any) {
    return res.status(500).json({ error: err?.message || 'Failed to update profile' });
  }
});

// ── POST /api/account/avatar ──────────────────────────────────────
const avatarSchema = z.object({
  data: z.string().min(10), // base64
  contentType: z.string().regex(/^image\/(png|jpe?g|webp|gif)$/i),
  fileName: z.string().max(160).optional(),
});

function extFromContentType(ct: string): string {
  const m = ct.toLowerCase();
  if (m.includes('png')) return 'png';
  if (m.includes('webp')) return 'webp';
  if (m.includes('gif')) return 'gif';
  return 'jpg';
}

async function ensureProfileRow(config: ServerConfig, user: any) {
  const sb = getServiceClient(config);
  const { data: profile, error } = await sb
    .from('profiles')
    .select('*')
    .eq('id', user.id)
    .maybeSingle();

  if (error) {
    throw new Error(`Failed to load profile row: ${error.message}`);
  }

  if (profile) return profile;

  const seed = {
    id: user.id,
    email: user.email ?? '',
    full_name: (user.user_metadata?.full_name as string | undefined)?.trim() || null,
    avatar_url: null,
    updated_at: new Date().toISOString(),
  };

  const { data: inserted, error: insertError } = await sb
    .from('profiles')
    .upsert(seed, { onConflict: 'id' })
    .select('*')
    .maybeSingle();

  if (insertError) {
    throw new Error(`Failed to create profile row: ${insertError.message}`);
  }

  if (!inserted) {
    throw new Error('Profile row could not be created');
  }

  return inserted;
}

accountRouter.post('/avatar', async (req, res) => {
  try {
    const config: ServerConfig = (req as any).serverConfig;
    const user = (req as any).authUser;
    const parsed = avatarSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: 'Invalid input', details: parsed.error.flatten().fieldErrors });
    }

    const buffer = Buffer.from(parsed.data.data, 'base64');
    if (buffer.length === 0) {
      return res.status(400).json({ error: 'Empty file' });
    }
    if (buffer.length > 10 * 1024 * 1024) {
      return res.status(413).json({ error: 'Avatar must be smaller than 10 MB' });
    }

    const workspaceId = await getUserPrimaryWorkspaceId(config, user.id);
    if (!workspaceId) {
      return res.status(400).json({ error: 'No workspace available for storage routing' });
    }

    const existingProfile = await ensureProfileRow(config, user);

    const ext = extFromContentType(parsed.data.contentType);
    const fileKey = `avatars/${user.id}/${Date.now()}-${crypto.randomBytes(4).toString('hex')}.${ext}`;

    const result = await uploadFile(config, {
      workspaceId,
      fileKey,
      data: buffer,
      contentType: parsed.data.contentType,
    });

    if (!result.success || !result.url) {
      return res.status(500).json({ error: result.error || 'Upload failed' });
    }

    const sb = getServiceClient(config);

    const prev = existingProfile?.avatar_url;
    if (prev && typeof prev === 'string') {
      const marker = `/avatars/${user.id}/`;
      const idx = prev.indexOf(marker);
      if (idx >= 0) {
        const oldKey = prev.slice(idx + 1); // strip leading slash
        if (oldKey && oldKey !== fileKey) {
          await deleteFile(config, workspaceId, oldKey).catch(() => undefined);
        }
      }
    }

    const { data: savedProfile, error: saveError } = await sb
      .from('profiles')
      .update({ avatar_url: result.url, updated_at: new Date().toISOString() })
      .eq('id', user.id)
      .select('id, avatar_url')
      .maybeSingle();

    if (saveError) {
      console.error('[account] avatar persistence error:', saveError.message, { userId: user.id, fileKey, url: result.url });
      return res.status(500).json({ error: 'Avatar uploaded but profile update failed' });
    }

    if (!savedProfile?.id || !savedProfile.avatar_url) {
      console.error('[account] avatar persistence missing row:', { userId: user.id, fileKey, url: result.url });
      return res.status(500).json({ error: 'Avatar uploaded but profile row was not updated' });
    }

    return res.json({
      success: true,
      url: savedProfile.avatar_url,
      fileKey: result.fileKey,
      provider: 'resolved',
    });
  } catch (err: any) {
    console.error('[account] avatar upload error:', err);
    return res.status(500).json({ error: err?.message || 'Avatar upload failed' });
  }
});

// ── DELETE /api/account/avatar ────────────────────────────────────
accountRouter.delete('/avatar', async (req, res) => {
  try {
    const config: ServerConfig = (req as any).serverConfig;
    const user = (req as any).authUser;
    const sb = getServiceClient(config);

    const workspaceId = await getUserPrimaryWorkspaceId(config, user.id);
    const { data: prevProfile } = await sb
      .from('profiles')
      .select('avatar_url')
      .eq('id', user.id)
      .maybeSingle();

    const prev = prevProfile?.avatar_url;
    if (prev && workspaceId && typeof prev === 'string') {
      const marker = `/avatars/${user.id}/`;
      const idx = prev.indexOf(marker);
      if (idx >= 0) {
        const oldKey = prev.slice(idx + 1);
        if (oldKey) await deleteFile(config, workspaceId, oldKey).catch(() => undefined);
      }
    }

    await sb
      .from('profiles')
      .update({ avatar_url: null, updated_at: new Date().toISOString() })
      .eq('id', user.id);

    return res.json({ success: true });
  } catch (err: any) {
    return res.status(500).json({ error: err?.message || 'Failed to remove avatar' });
  }
});

// ── POST /api/account/change-password ─────────────────────────────
// Verifies current password by attempting a password sign-in, then updates.
const changePasswordSchema = z.object({
  currentPassword: z.string().min(1).max(255),
  newPassword: z.string().min(8).max(255),
});

accountRouter.post('/change-password', async (req, res) => {
  try {
    const config: ServerConfig = (req as any).serverConfig;
    const user = (req as any).authUser;
    const parsed = changePasswordSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: 'New password must be at least 8 characters' });
    }

    if (!user.email) {
      return res.status(400).json({ error: 'Account has no email' });
    }

    // Re-auth with a throwaway anon client (does not affect current session)
    const { createClient } = await import('@supabase/supabase-js');
    const verifier = createClient(config.supabaseUrl, config.supabaseAnonKey, {
      auth: { autoRefreshToken: false, persistSession: false },
    });
    const { error: signInErr } = await verifier.auth.signInWithPassword({
      email: user.email,
      password: parsed.data.currentPassword,
    });
    if (signInErr) {
      return res.status(400).json({ error: 'Current password is incorrect' });
    }

    const sb = getServiceClient(config);
    const { error: updErr } = await sb.auth.admin.updateUserById(user.id, {
      password: parsed.data.newPassword,
    });
    if (updErr) {
      return res.status(500).json({ error: updErr.message });
    }

    return res.json({ success: true });
  } catch (err: any) {
    return res.status(500).json({ error: err?.message || 'Failed to change password' });
  }
});

// ─── SECURITY: Active sessions + login history ───────────────────
//
// We read directly from Supabase's managed `auth.sessions` table via
// service-role; the JS SDK does not expose a list endpoint for it.
// `auth.sessions` columns we rely on:
//   id (uuid), user_id (uuid), created_at, updated_at, refreshed_at,
//   user_agent (text), ip (inet), not_after (timestamptz)
//
// `login_attempts` (already in our schema) powers the recent login history.

interface SessionRow {
  id: string;
  user_id: string;
  created_at: string | null;
  updated_at: string | null;
  refreshed_at: string | null;
  not_after: string | null;
  user_agent: string | null;
  ip: string | null;
}

function parseUserAgent(ua: string | null): { browser: string; os: string; device: string } {
  if (!ua) return { browser: 'Unknown', os: 'Unknown', device: 'Unknown' };
  const lower = ua.toLowerCase();
  let browser = 'Unknown';
  if (lower.includes('edg/')) browser = 'Edge';
  else if (lower.includes('chrome/') && !lower.includes('chromium')) browser = 'Chrome';
  else if (lower.includes('firefox/')) browser = 'Firefox';
  else if (lower.includes('safari/') && !lower.includes('chrome')) browser = 'Safari';
  else if (lower.includes('opera') || lower.includes('opr/')) browser = 'Opera';

  let os = 'Unknown';
  if (lower.includes('windows nt')) os = 'Windows';
  else if (lower.includes('mac os x') || lower.includes('macintosh')) os = 'macOS';
  else if (lower.includes('android')) os = 'Android';
  else if (lower.includes('iphone') || lower.includes('ipad') || lower.includes('ios')) os = 'iOS';
  else if (lower.includes('linux')) os = 'Linux';

  let device = 'Desktop';
  if (lower.includes('mobile') || lower.includes('iphone') || lower.includes('android')) device = 'Mobile';
  else if (lower.includes('tablet') || lower.includes('ipad')) device = 'Tablet';

  return { browser, os, device };
}

async function enrichIpForDisplay(config: ServerConfig, rawIp: string | null) {
  if (!rawIp) {
    return { ip_display: '', country: null as string | null, country_code: null as string | null, city: null as string | null, region: null as string | null };
  }
  try {
    const geo = await resolveVisitorGeo(config, null, {
      raw_ip: rawIp,
      ip_hash: hashIp(rawIp),
    });
    return {
      ip_display: maskIp(rawIp),
      country: geo.country,
      country_code: geo.country_code,
      city: geo.city,
      region: geo.region,
    };
  } catch {
    return { ip_display: maskIp(rawIp), country: null, country_code: null, city: null, region: null };
  }
}

/**
 * GET /api/account/security/sessions
 * Lists every active Supabase auth session for the current user, enriched
 * with parsed UA + geo (best-effort). The current session id is computed
 * by matching the bearer token's `session_id` claim when available.
 */
accountRouter.get('/security/sessions', async (req, res) => {
  try {
    const config: ServerConfig = (req as any).serverConfig;
    const user = (req as any).authUser;
    const sb = getServiceClient(config);

    const { data, error } = await sb
      .schema('auth' as any)
      .from('sessions' as any)
      .select('id, user_id, created_at, updated_at, refreshed_at, not_after, user_agent, ip')
      .eq('user_id', user.id)
      .order('updated_at', { ascending: false })
      .limit(50);

    if (error) {
      console.error('[account/security] list sessions error:', error.message);
      return res.status(500).json({ error: 'Failed to load sessions' });
    }

    // Decode the caller token to detect the active session id (if present).
    let currentSessionId: string | null = null;
    try {
      const auth = req.headers.authorization || '';
      const tok = auth.startsWith('Bearer ') ? auth.slice(7) : '';
      const parts = tok.split('.');
      if (parts.length === 3) {
        const payload = JSON.parse(Buffer.from(parts[1], 'base64url').toString('utf8'));
        if (typeof payload?.session_id === 'string') currentSessionId = payload.session_id;
      }
    } catch {
      // ignore — current-session detection is purely cosmetic.
    }

    const rows = (data ?? []) as SessionRow[];
    const enriched = await Promise.all(rows.map(async (row) => {
      const ua = parseUserAgent(row.user_agent);
      const geo = await enrichIpForDisplay(config, row.ip);
      return {
        id: row.id,
        is_current: currentSessionId ? row.id === currentSessionId : false,
        created_at: row.created_at,
        last_active_at: row.refreshed_at || row.updated_at || row.created_at,
        not_after: row.not_after,
        user_agent_raw: row.user_agent,
        browser: ua.browser,
        os: ua.os,
        device: ua.device,
        ip: geo.ip_display,
        country: geo.country,
        country_code: geo.country_code,
        city: geo.city,
        region: geo.region,
      };
    }));

    return res.json({ sessions: enriched, current_session_id: currentSessionId });
  } catch (err: any) {
    console.error('[account/security] sessions error:', err);
    return res.status(500).json({ error: err?.message || 'Failed to load sessions' });
  }
});

/**
 * DELETE /api/account/security/sessions/:id
 * Revoke a single session by id (or `?all=1` to revoke every session except
 * the current one). Deletion of the row in `auth.sessions` invalidates
 * Supabase refresh tokens immediately; access tokens expire on their normal
 * 1h schedule.
 */
accountRouter.delete('/security/sessions/:id', async (req, res) => {
  try {
    const config: ServerConfig = (req as any).serverConfig;
    const user = (req as any).authUser;
    const sb = getServiceClient(config);
    const sessionId = String(req.params.id || '').trim();
    const all = req.query.all === '1' || req.query.all === 'true';

    if (!all && !sessionId) {
      return res.status(400).json({ error: 'Missing session id' });
    }

    // Detect current session id so "revoke all others" doesn't kick the caller.
    let currentSessionId: string | null = null;
    try {
      const auth = req.headers.authorization || '';
      const tok = auth.startsWith('Bearer ') ? auth.slice(7) : '';
      const parts = tok.split('.');
      if (parts.length === 3) {
        const payload = JSON.parse(Buffer.from(parts[1], 'base64url').toString('utf8'));
        if (typeof payload?.session_id === 'string') currentSessionId = payload.session_id;
      }
    } catch { /* ignore */ }

    const table = sb.schema('auth' as any).from('sessions' as any);
    let query = table.delete().eq('user_id', user.id);
    if (all) {
      if (currentSessionId) query = query.neq('id', currentSessionId);
    } else {
      query = query.eq('id', sessionId);
    }
    const { error } = await query;
    if (error) {
      console.error('[account/security] revoke session error:', error.message);
      return res.status(500).json({ error: 'Failed to revoke session' });
    }
    return res.json({ success: true });
  } catch (err: any) {
    console.error('[account/security] revoke error:', err);
    return res.status(500).json({ error: err?.message || 'Failed to revoke session' });
  }
});

/**
 * GET /api/account/security/login-history
 * Returns the most recent login attempts (success + failure) from the
 * `login_attempts` table, scoped to the caller's email.
 */
accountRouter.get('/security/login-history', async (req, res) => {
  try {
    const config: ServerConfig = (req as any).serverConfig;
    const user = (req as any).authUser;
    if (!user.email) return res.json({ entries: [] });
    const sb = getServiceClient(config);

    const limit = Math.min(Math.max(Number(req.query.limit) || 25, 1), 100);

    const { data, error } = await sb
      .from('login_attempts')
      .select('id, email, ip_address, success, created_at')
      .eq('email', user.email.trim().toLowerCase())
      .order('created_at', { ascending: false })
      .limit(limit);

    if (error) {
      console.error('[account/security] login history error:', error.message);
      return res.status(500).json({ error: 'Failed to load login history' });
    }

    const entries = await Promise.all((data ?? []).map(async (row: any) => {
      const geo = await enrichIpForDisplay(config, row.ip_address);
      return {
        id: row.id,
        created_at: row.created_at,
        success: !!row.success,
        ip: geo.ip_display,
        country: geo.country,
        country_code: geo.country_code,
        city: geo.city,
        region: geo.region,
      };
    }));

    return res.json({ entries });
  } catch (err: any) {
    console.error('[account/security] login-history error:', err);
    return res.status(500).json({ error: err?.message || 'Failed to load login history' });
  }
});

// ─── WORKSPACE ICON UPLOAD ──────────────────────────────────────
//
// Mirrors the avatar upload flow but writes to the workspace-scoped
// `branding/<workspaceId>/icon-...` key and persists the resulting URL
// to `workspace_branding.logo_url`. Caller must be a member of the
// workspace (any role) — verified by RLS via service-role lookup.

const workspaceIconSchema = z.object({
  workspaceId: z.string().uuid(),
  data: z.string().min(10),
  contentType: z.string().regex(/^image\/(png|jpe?g|webp|gif|svg\+xml)$/i),
  fileName: z.string().max(160).optional(),
});

async function userIsWorkspaceMember(config: ServerConfig, userId: string, workspaceId: string): Promise<boolean> {
  const sb = getServiceClient(config);
  const { data } = await sb
    .from('workspace_members')
    .select('id')
    .eq('user_id', userId)
    .eq('workspace_id', workspaceId)
    .maybeSingle();
  return !!data;
}

accountRouter.post('/workspace-icon', async (req, res) => {
  try {
    const config: ServerConfig = (req as any).serverConfig;
    const user = (req as any).authUser;
    const parsed = workspaceIconSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: 'Invalid input', details: parsed.error.flatten().fieldErrors });
    }

    const { workspaceId, contentType } = parsed.data;
    if (!(await userIsWorkspaceMember(config, user.id, workspaceId))) {
      return res.status(403).json({ error: 'Not a member of this workspace' });
    }

    const buffer = Buffer.from(parsed.data.data, 'base64');
    if (buffer.length === 0) return res.status(400).json({ error: 'Empty file' });
    if (buffer.length > 5 * 1024 * 1024) {
      return res.status(413).json({ error: 'Icon must be smaller than 5 MB' });
    }

    const ext = extFromContentType(contentType);
    const fileKey = `branding/${workspaceId}/icon-${Date.now()}-${crypto.randomBytes(4).toString('hex')}.${ext}`;

    const result = await uploadFile(config, {
      workspaceId,
      fileKey,
      data: buffer,
      contentType,
    });
    if (!result.success || !result.url) {
      return res.status(500).json({ error: result.error || 'Upload failed' });
    }

    const sb = getServiceClient(config);

    // Best-effort cleanup of the previous icon
    const { data: prevBranding } = await sb
      .from('workspace_branding')
      .select('logo_url')
      .eq('workspace_id', workspaceId)
      .maybeSingle();
    const prev = prevBranding?.logo_url;
    if (prev && typeof prev === 'string') {
      const marker = `/branding/${workspaceId}/`;
      const idx = prev.indexOf(marker);
      if (idx >= 0) {
        const oldKey = prev.slice(idx + 1);
        if (oldKey && oldKey !== fileKey) {
          await deleteFile(config, workspaceId, oldKey).catch(() => undefined);
        }
      }
    }

    const { error: saveError } = await sb
      .from('workspace_branding')
      .update({ logo_url: result.url, updated_at: new Date().toISOString() })
      .eq('workspace_id', workspaceId);

    if (saveError) {
      console.error('[account] workspace icon persistence error:', saveError.message);
      return res.status(500).json({ error: 'Icon uploaded but workspace update failed' });
    }

    return res.json({ success: true, url: result.url, fileKey: result.fileKey });
  } catch (err: any) {
    console.error('[account] workspace icon upload error:', err);
    return res.status(500).json({ error: err?.message || 'Workspace icon upload failed' });
  }
});

accountRouter.delete('/workspace-icon', async (req, res) => {
  try {
    const config: ServerConfig = (req as any).serverConfig;
    const user = (req as any).authUser;
    const workspaceId = String(req.query.workspaceId || '').trim();
    if (!workspaceId) return res.status(400).json({ error: 'Missing workspaceId' });
    if (!(await userIsWorkspaceMember(config, user.id, workspaceId))) {
      return res.status(403).json({ error: 'Not a member of this workspace' });
    }

    const sb = getServiceClient(config);
    const { data: prevBranding } = await sb
      .from('workspace_branding')
      .select('logo_url')
      .eq('workspace_id', workspaceId)
      .maybeSingle();
    const prev = prevBranding?.logo_url;
    if (prev && typeof prev === 'string') {
      const marker = `/branding/${workspaceId}/`;
      const idx = prev.indexOf(marker);
      if (idx >= 0) {
        const oldKey = prev.slice(idx + 1);
        if (oldKey) await deleteFile(config, workspaceId, oldKey).catch(() => undefined);
      }
    }

    await sb
      .from('workspace_branding')
      .update({ logo_url: null, updated_at: new Date().toISOString() })
      .eq('workspace_id', workspaceId);

    return res.json({ success: true });
  } catch (err: any) {
    return res.status(500).json({ error: err?.message || 'Failed to remove workspace icon' });
  }
});