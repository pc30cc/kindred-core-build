<?php
namespace Respok\OpenCart;

/**
 * Where RESPOK lives. Fixed in the package (the build can substitute other
 * addresses for a self-hosted RESPOK); the store owner never types them.
 *
 * A staging or test install can point the extension elsewhere by defining
 * RESPOK_APP_URL / RESPOK_API_URL (and, for its own release key,
 * RESPOK_UPDATE_PUBLIC_KEY) in OpenCart's config.php. Writing config.php
 * already means full control of the shop, so this opens nothing new.
 */
final class Endpoints {
	public const APP_URL = 'https://app.respok.app';
	public const API_URL = 'https://api.respok.app';

	public static function app(): string {
		return rtrim(defined('RESPOK_APP_URL') ? (string)constant('RESPOK_APP_URL') : self::APP_URL, '/');
	}

	public static function api(): string {
		return rtrim(defined('RESPOK_API_URL') ? (string)constant('RESPOK_API_URL') : self::API_URL, '/');
	}

	public static function updatePublicKey(): string {
		return defined('RESPOK_UPDATE_PUBLIC_KEY') ? (string)constant('RESPOK_UPDATE_PUBLIC_KEY') : Protocol::UPDATE_PUBLIC_KEY;
	}
}
