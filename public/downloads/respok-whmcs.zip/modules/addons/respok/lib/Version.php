<?php

namespace Respok\Whmcs;

/**
 * Versions the two ends of the protocol agree on. The protocol string and the
 * signing scheme are shared with the WooCommerce connector
 * (server/services/commerce/signing.ts on the RESPOK side).
 */
final class Version
{
    const ADDON = '1.2.2';
    const PROTOCOL = 'platform-commerce/1';
    /** Logical path covered by every request signature (not the URL path). */
    const API_CANONICAL_PATH = '/platform/whmcs/v1';
    /** Minimum WHMCS: 8.0 introduced Users/Client Accounts and CurrentUser. */
    const MIN_WHMCS = '8.0.0';
    const MIN_PHP = '7.2.0';
}
