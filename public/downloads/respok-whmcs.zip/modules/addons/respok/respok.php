<?php
/**
 * RESPOK for WHMCS — addon module entry point.
 *
 * Lets the RESPOK AI assistant (already embedded as the RESPOK widget)
 * recognise a logged-in WHMCS customer and answer about THEIR OWN services,
 * domains, invoices, orders and tickets, plus public plans — by asking this
 * WHMCS install live, one bounded question at a time. No customer data is
 * copied to RESPOK; no cron, no sync, no polling.
 *
 * Requirements: WHMCS 8.0+ (Users & Client Accounts, CurrentUser), PHP 7.2+.
 */

if (!defined('WHMCS')) {
    die('This file cannot be accessed directly');
}

require_once __DIR__ . '/lib/bootstrap.php';

use Respok\Whmcs\Admin\Page;
use Respok\Whmcs\Schema;
use Respok\Whmcs\Settings;
use Respok\Whmcs\Version;

function respok_config()
{
    return array(
        'name' => 'RESPOK',
        'description' => 'Connects the RESPOK AI assistant to this WHMCS so it can answer customers about their own services, domains, invoices, orders and tickets. Read-only; nothing is copied out of WHMCS.',
        'author' => 'RESPOK',
        'language' => 'english',
        'version' => Version::ADDON,
        'fields' => array(),
    );
}

function respok_activate()
{
    if (version_compare(PHP_VERSION, Version::MIN_PHP, '<')) {
        return array('status' => 'error', 'description' => 'RESPOK requires PHP ' . Version::MIN_PHP . ' or newer.');
    }
    if (!class_exists('\WHMCS\Authentication\CurrentUser')) {
        return array('status' => 'error', 'description' => 'RESPOK requires WHMCS ' . Version::MIN_WHMCS . ' or newer.');
    }
    try {
        Schema::install();
        Schema::resetCache();
        Schema::supportedCapabilities(false);
    } catch (\Exception $e) {
        return array('status' => 'error', 'description' => 'RESPOK could not create its tables.');
    }
    return array('status' => 'success', 'description' => 'RESPOK activated. Open Addons → RESPOK to connect it to your workspace.');
}

/**
 * Removes ONLY what this addon created (its three mod_respok_* tables). No
 * WHMCS client, service, domain, invoice, order or ticket is touched. RESPOK
 * is told (best effort) that the connection is gone.
 */
function respok_deactivate()
{
    try {
        if (Settings::credential() !== null) {
            \Respok\Whmcs\Pairing::disconnect();
        }
    } catch (\Exception $e) {
        // Local cleanup never depends on the network.
    }
    try {
        Schema::uninstall();
    } catch (\Exception $e) {
        return array('status' => 'error', 'description' => 'RESPOK could not remove its tables.');
    }
    return array('status' => 'success', 'description' => 'RESPOK deactivated. Its own tables were removed; your WHMCS data was not touched.');
}

function respok_upgrade($vars)
{
    Schema::install();
    Schema::resetCache();
    Schema::supportedCapabilities(false);
}

function respok_output($vars)
{
    Page::render(is_array($vars) ? $vars : array());
}
