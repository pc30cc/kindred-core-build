=== اتصال‌دهنده‌ی RESPOK برای ووکامرس ===
Contributors: respok
Tags: woocommerce, ai, chat, customer support, commerce
Requires at least: 6.0
Tested up to: 6.7
Requires PHP: 7.4
WC requires at least: 8.0
WC tested up to: 9.4
Stable tag: 1.2.5
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

پل ارتباطی سبک و امن میان فروشگاه ووکامرس شما و دستیار هوش مصنوعی RESPOK.

== توضیحات ==

این افزونه هیچ مدل هوش مصنوعی اجرا نمی‌کند، پرامپتی نمی‌سازد، embedding یا نمایه‌ی برداری تولید نمی‌کند و هیچ پردازش هوش مصنوعی در پس‌زمینه انجام نمی‌دهد. تمام این موارد روی زیرساخت خود RESPOK اجرا می‌شوند. وظیفه‌ی این افزونه محدود و امن است:

* پاسخ‌دهی به درخواست‌های امضاشده و احرازهویت‌شده‌ی RESPOK درباره‌ی محصولات، موجودی، سفارش‌ها و رهگیری مرسوله
* ارسال رویدادهای محدود تغییر محصول/سفارش به RESPOK در پس‌زمینه، از طریق Action Scheduler خود ووکامرس
* اتصال به ورک‌اسپیس RESPOK شما با یک فرآیند احرازهویت شبیه OAuth و تنها با یک کلیک (بدون نیاز به کپی/پیست کلید API)

فروشگاه و فرآیند پرداخت شما هرگز توسط RESPOK کند نمی‌شود: نصب این افزونه هیچ درخواست شبکه‌ای هم‌زمان (synchronous) به بارگذاری صفحات معمولی اضافه نمی‌کند و فرآیند تسویه‌حساب هرگز منتظر RESPOK نمی‌ماند. اگر RESPOK در دسترس نباشد، فروشگاه شما دقیقاً مثل قبل کار می‌کند — سبد خرید، تسویه‌حساب، پرداخت و ثبت سفارش کاملاً بدون تأثیر باقی می‌مانند.

= پیش‌نیازها =

* PHP نسخه‌ی ۷.۴ به بالا
* وردپرس نسخه‌ی ۶.۰ به بالا
* ووکامرس نسخه‌ی ۸.۰ به بالا (فعال)
* سازگار با HPOS (ذخیره‌سازی سفارش با کارایی بالا) — هم با HPOS فعال و هم با ذخیره‌سازی سنتی مبتنی بر پست تست شده است

= امنیت =

* بدون کپی/پیست Consumer Key/Secret — اتصال از طریق فرآیند authorization-code شبیه OAuth همراه با PKCE انجام می‌شود
* تمام درخواست‌های ماشینی با HMAC-SHA256 امضا می‌شوند، همراه با محافظت در برابر تکرار درخواست (replay) و بازه‌ی زمانی محدود
* اطلاعات اتصال به‌صورت رمزنگاری‌شده ذخیره می‌شوند و هرگز از طریق REST بازگردانده، لاگ یا در HTML/JS جاسازی نمی‌شوند
* اطلاعات سفارش و مشتری هرگز بدون احراز هویت تأییدشده نمایش داده نمی‌شوند — صرفاً داشتن شماره‌ی سفارش کافی نیست

برای مستندات کامل معماری و امنیت، به پوشه‌ی docs/commerce/ در مخزن RESPOK مراجعه کنید.

== نصب ==

۱. افزونه را نصب و فعال کنید.
۲. در وردپرس به بخش «ووکامرس ← RESPOK» (یا آیتم منوی «RESPOK») بروید.
۳. آدرس داشبورد RESPOK خود را (مثلاً https://app.respok.app) وارد کرده و روی «اتصال به RESPOK» کلیک کنید.
۴. وارد حساب کاربری خود شوید، ورک‌اسپیس مدنظر را انتخاب کنید و سطوح دسترسی را تأیید کنید.

== Changelog ==

= 1.2.5 =
* Updates install only when signed by the RESPOK release key and matching its checksum.
* Only administrators can connect, disconnect or change the RESPOK URL (https only).

= 1.2.4 =
* Format update notes in the WordPress plugin details window.

= 1.2.3 =
* The admin page follows the WordPress language (English or Persian).
* Shorter update notes and clearer messages in the admin.

= 1.2.2 =
* More reliable order lookup and safer plugin updates.

= 1.2.1 =
* Customer order details and tracking require verified access.

= 1.2.0 =
* Added automatic updates, product reviews, and signed customer sign-in for chat.

= 1.1.0 =
* Improved the connection settings page.

= 1.0.0 =
* First release of the RESPOK store connection.

== Changelog fa_IR ==

= 1.2.5 =
* به‌روزرسانی فقط با امضای RESPOK و تطابق چک‌سام نصب می‌شود.
* اتصال، قطع اتصال و تغییر آدرس RESPOK (فقط https) فقط برای مدیر سایت ممکن است.

= 1.2.4 =
* نمایش خوانای تغییرات در پنجرهٔ جزئیات افزونه.

= 1.2.3 =
* صفحه مدیریت با زبان وردپرس فارسی یا انگلیسی نمایش داده می‌شود.
* یادداشت‌های به‌روزرسانی و پیام‌های مدیریت کوتاه‌تر و روشن‌تر شدند.

= 1.2.2 =
* جست‌وجوی سفارش و به‌روزرسانی افزونه مطمئن‌تر شد.

= 1.2.1 =
* نمایش سفارش و رهگیری فقط پس از تأیید دسترسی مشتری انجام می‌شود.

= 1.2.0 =
* به‌روزرسانی خودکار، نظرات محصول و شناسایی مشتری واردشده در گفتگو اضافه شد.

= 1.1.0 =
* صفحه تنظیمات اتصال بهبود یافت.

= 1.0.0 =
* نسخه نخست اتصال فروشگاه به RESPOK.
