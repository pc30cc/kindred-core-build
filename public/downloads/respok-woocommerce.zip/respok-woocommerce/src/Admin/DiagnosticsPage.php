<?php
namespace Respok\WooCommerce\Admin;

use Respok\WooCommerce\Auth\PairingService;
use Respok\WooCommerce\Support\Updater;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Technical detail for the day something breaks — safe metadata only, never
 * the installation secret.
 *
 * Collapsed by default: a shop owner opening this screen wants to know the
 * store is connected, not which protocol revision it negotiated. It opens
 * itself only when there are failed deliveries, i.e. exactly when the
 * detail is the reason the admin came here.
 */
final class DiagnosticsPage {

	public static function render( array $credential, array $settings = array() ): void {
		$dead_letters = get_option( 'respok_wc_dead_letters', array() );
		if ( ! is_array( $dead_letters ) ) {
			$dead_letters = array();
		}
		$has_failures = ! empty( $dead_letters );
		?>
		<details class="respok-more"<?php echo $has_failures ? ' open' : ''; ?>>
			<summary>
				<?php
				if ( $has_failures ) {
					printf(
						/* translators: %d: number of failed event deliveries */
						esc_html__( 'Technical details: %d failed events', 'respok-woocommerce' ),
						count( $dead_letters )
					);
				} else {
					esc_html_e( 'Technical details', 'respok-woocommerce' );
				}
				?>
			</summary>
			<div class="respok-more-body">
				<dl class="respok-rows">
					<div>
						<dt class="respok-k"><?php esc_html_e( 'API URL', 'respok-woocommerce' ); ?></dt>
						<dd class="respok-v">
							<code><?php echo esc_html( PairingService::api_base_url() ); ?></code>
							<?php if ( empty( $settings['api_url'] ) ) : ?>
								<span class="respok-hint">(<?php esc_html_e( 'Same as dashboard', 'respok-woocommerce' ); ?>)</span>
							<?php endif; ?>
						</dd>
					</div>
					<div>
						<dt class="respok-k"><?php esc_html_e( 'Plugin version', 'respok-woocommerce' ); ?></dt>
						<dd class="respok-v"><code><?php echo esc_html( RESPOK_WC_VERSION ); ?></code></dd>
					</div>
					<?php $update_status = Updater::status(); ?>
					<?php if ( null !== $update_status ) : ?>
					<div>
						<dt class="respok-k"><?php esc_html_e( 'Updates', 'respok-woocommerce' ); ?></dt>
						<dd class="respok-v"><?php echo esc_html( Updater::status_label( $update_status['code'] ) ); ?> <code><?php echo esc_html( $update_status['code'] ); ?></code></dd>
					</div>
					<?php endif; ?>
					<div>
						<dt class="respok-k"><?php esc_html_e( 'Protocol version', 'respok-woocommerce' ); ?></dt>
						<dd class="respok-v"><code><?php echo esc_html( $credential['protocol_version'] ?? __( 'Not available', 'respok-woocommerce' ) ); ?></code></dd>
					</div>
					<div>
						<dt class="respok-k"><?php esc_html_e( 'Connected at', 'respok-woocommerce' ); ?></dt>
						<dd class="respok-v"><?php echo esc_html( ! empty( $credential['created_at'] ) ? gmdate( 'Y-m-d H:i', (int) $credential['created_at'] ) . ' UTC' : __( 'Not available', 'respok-woocommerce' ) ); ?></dd>
					</div>
					<div>
						<dt class="respok-k"><?php esc_html_e( 'Failed events (latest 50)', 'respok-woocommerce' ); ?></dt>
						<dd class="respok-v"><?php echo esc_html( (string) count( $dead_letters ) ); ?></dd>
					</div>
				</dl>

				<?php if ( $has_failures ) : ?>
					<table class="respok-table">
						<thead>
							<tr>
								<th><?php esc_html_e( 'Type', 'respok-woocommerce' ); ?></th>
								<th><?php esc_html_e( 'Reason', 'respok-woocommerce' ); ?></th>
								<th><?php esc_html_e( 'Time', 'respok-woocommerce' ); ?></th>
							</tr>
						</thead>
						<tbody>
							<?php foreach ( array_reverse( $dead_letters ) as $entry ) : ?>
								<tr>
									<td><?php echo esc_html( $entry['type'] ?? __( 'Not available', 'respok-woocommerce' ) ); ?></td>
									<td><?php echo esc_html( $entry['reason'] ?? __( 'Not available', 'respok-woocommerce' ) ); ?></td>
									<td><?php echo esc_html( $entry['at'] ?? __( 'Not available', 'respok-woocommerce' ) ); ?></td>
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				<?php endif; ?>
			</div>
		</details>
		<?php
	}
}
