<?php
namespace Respok\WooCommerce\Admin;

use Respok\WooCommerce\Auth\CredentialStore;
use Respok\WooCommerce\Auth\PairingService;
use Respok\WooCommerce\Events\EventDelivery;
use Respok\WooCommerce\Support\Capabilities;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The ENTIRE WordPress-side admin UI (spec §34/§84). No AI prompt/model
 * settings, no analytics dashboard, no Knowledge Base editor — those live
 * in RESPOK. This is a small, professional settings screen only.
 *
 * What a shop owner needs from this screen is short: is my store connected,
 * does the assistant appear on my site, and how do I stop it. Everything
 * else — protocol version, installation identifiers, delivery failures — is
 * for the one day something breaks, so it sits behind a disclosure instead
 * of competing with the three things that matter.
 *
 * WordPress selects the translation for the current admin language.
 * English is the source locale, and Persian is shipped in languages/.
 */
final class SettingsPage {

	private const PAGE_SLUG = 'respok-woocommerce';

	/**
	 * Vazirmatn — the de-facto standard Persian UI face. Loaded from Google
	 * Fonts, and ONLY on this plugin's own screen: a font request on every
	 * admin page would be an unasked-for third-party call on screens that
	 * have nothing to do with this plugin.
	 *
	 * Filterable so an air-gapped or privacy-restricted site can point it at
	 * a self-hosted copy or return '' to skip the request entirely — the
	 * stylesheet falls back to the system UI stack either way, so the screen
	 * is never left unstyled.
	 */
	private const FONT_URL = 'https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;500;600;700&display=swap';

	public function register(): void {
		add_action( 'admin_menu', array( $this, 'add_menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
	}

	public function add_menu(): void {
		add_menu_page(
			__( 'RESPOK', 'respok-woocommerce' ),
			__( 'RESPOK', 'respok-woocommerce' ),
			Capabilities::MANAGE_CAPABILITY,
			self::PAGE_SLUG,
			array( $this, 'render' ),
			'dashicons-format-chat',
			58
		);
	}

	/** Styles load on this plugin's screen only — never site-wide. */
	public function enqueue_assets( string $hook_suffix ): void {
		if ( 'toplevel_page_' . self::PAGE_SLUG !== $hook_suffix ) {
			return;
		}

		$font_url = is_rtl() ? (string) apply_filters( 'respok_wc_admin_font_url', self::FONT_URL ) : '';
		if ( '' !== $font_url ) {
			// phpcs:ignore WordPress.WP.EnqueuedResourceParameters.MissingVersion -- Google Fonts URLs are already versioned by their query string; appending ?ver= breaks the request.
			wp_enqueue_style( 'respok-wc-admin-font', $font_url, array(), null );
		}

		wp_enqueue_style(
			'respok-wc-admin',
			RESPOK_WC_URL . 'assets/admin.css',
			'' !== $font_url ? array( 'respok-wc-admin-font' ) : array(),
			RESPOK_WC_VERSION
		);
	}

	public function render(): void {
		if ( ! Capabilities::current_user_can_manage() ) {
			wp_die( esc_html__( 'You cannot access this page.', 'respok-woocommerce' ) );
		}

		$credential = CredentialStore::get();
		$settings   = get_option( 'respok_wc_settings', array( 'auto_widget' => true ) );
		if ( ! is_array( $settings ) ) {
			$settings = array();
		}

		$notice_type    = isset( $_GET['respok_notice'] ) ? sanitize_key( $_GET['respok_notice'] ) : null; // phpcs:ignore
		$notice_message = isset( $_GET['respok_message'] ) ? sanitize_text_field( wp_unslash( $_GET['respok_message'] ) ) : null; // phpcs:ignore
		?>
		<div class="wrap respok-admin" dir="<?php echo is_rtl() ? 'rtl' : 'ltr'; ?>">
			<div class="respok-head">
				<div class="respok-mark" aria-hidden="true"><?php echo is_rtl() ? 'و' : 'W'; ?></div>
				<div>
					<h1><?php esc_html_e( 'RESPOK', 'respok-woocommerce' ); ?></h1>
					<p><?php esc_html_e( 'Your store assistant', 'respok-woocommerce' ); ?></p>
				</div>
			</div>

			<?php if ( $notice_type && $notice_message ) : ?>
				<div class="respok-notice <?php echo 'error' === $notice_type ? 'is-error' : 'is-success'; ?>">
					<?php echo esc_html( $notice_message ); ?>
				</div>
			<?php endif; ?>

			<?php
			if ( null === $credential && ! Capabilities::current_user_can_connect() ) {
				// Shop managers see the status, but which RESPOK the store
				// trusts is an administrator's decision (see Capabilities).
				?>
				<div class="respok-card">
					<h2><?php esc_html_e( 'Connect your store', 'respok-woocommerce' ); ?></h2>
					<p class="respok-sub"><?php esc_html_e( 'The store is not connected to RESPOK. Ask a site administrator to connect it.', 'respok-woocommerce' ); ?></p>
				</div>
				<?php
			} elseif ( null === $credential ) {
				$this->render_connect_form( $settings );
			} else {
				$this->render_connected( $credential, $settings );
			}
			?>
		</div>
		<?php
	}

	/** Not connected yet — one field, one button, everything else out of the way. */
	private function render_connect_form( array $settings ): void {
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<?php wp_nonce_field( 'respok_wc_connect' ); ?>
			<input type="hidden" name="action" value="respok_wc_connect" />

			<div class="respok-card">
				<h2><?php esc_html_e( 'Connect your store', 'respok-woocommerce' ); ?></h2>
				<p class="respok-sub">
					<?php esc_html_e( 'Connect your store to RESPOK to answer customers using your products, prices, stock, and orders.', 'respok-woocommerce' ); ?>
				</p>

				<div class="respok-field">
					<label for="respok_wc_app_url"><?php esc_html_e( 'RESPOK URL', 'respok-woocommerce' ); ?></label>
					<input
						type="url" id="respok_wc_app_url" name="app_url" dir="ltr" required pattern="https://.+"
						placeholder="https://app.respok.app"
						value="<?php echo esc_attr( $settings['app_url'] ?? '' ); ?>"
					/>
					<p class="respok-help">
						<?php esc_html_e( 'The URL you use to sign in to RESPOK.', 'respok-woocommerce' ); ?>
					</p>
				</div>

				<button type="submit" class="respok-btn respok-btn-primary">
					<?php esc_html_e( 'Connect to RESPOK', 'respok-woocommerce' ); ?>
				</button>
			</div>

			<details class="respok-more"<?php echo ! empty( $settings['api_url'] ) ? ' open' : ''; ?>>
				<summary><?php esc_html_e( 'Advanced settings', 'respok-woocommerce' ); ?></summary>
				<div class="respok-more-body">
					<div class="respok-field">
						<label for="respok_wc_api_url"><?php esc_html_e( 'API URL', 'respok-woocommerce' ); ?></label>
						<input
							type="url" id="respok_wc_api_url" name="api_url" dir="ltr" pattern="https://.+"
							placeholder="https://api.respok.app"
							value="<?php echo esc_attr( $settings['api_url'] ?? '' ); ?>"
						/>
						<p class="respok-help">
							<?php esc_html_e( 'Enter this only if the RESPOK API has a separate URL. Otherwise leave it empty.', 'respok-woocommerce' ); ?>
						</p>
					</div>
				</div>
			</details>
		</form>
		<?php
	}

	/** Connected — status, the one switch that matters, then the actions. */
	private function render_connected( array $credential, array $settings ): void {
		// A stored credential is not the same as a WORKING one: if RESPOK
		// rotated or revoked the secret, every signed call fails while a
		// naive "connected" badge would still look healthy.
		$auth_error = get_option( EventDelivery::AUTH_ERROR_OPTION, null );
		$rejected   = is_array( $auth_error );
		?>
		<div class="respok-card">
			<div class="respok-status <?php echo $rejected ? 'is-bad' : ''; ?>">
				<span class="respok-dot" aria-hidden="true"></span>
				<?php
				echo $rejected
					? esc_html__( 'Connection credentials rejected', 'respok-woocommerce' )
					: esc_html__( 'Store connected', 'respok-woocommerce' );
				?>
			</div>

			<?php if ( $rejected ) : ?>
				<p class="respok-sub" style="margin-top:10px">
					<?php
					printf(
						/* translators: 1: HTTP status RESPOK replied with, 2: UTC time of the rejection */
						esc_html__( 'RESPOK rejected the last signed request with code %1$d at %2$s. Disconnect and reconnect your store.', 'respok-woocommerce' ),
						(int) ( $auth_error['status'] ?? 0 ),
						esc_html( (string) ( $auth_error['at'] ?? '' ) )
					);
					?>
				</p>
			<?php endif; ?>

			<dl class="respok-rows">
				<div>
					<dt class="respok-k"><?php esc_html_e( 'Store', 'respok-woocommerce' ); ?></dt>
					<dd class="respok-v"><?php echo esc_html( wp_parse_url( home_url(), PHP_URL_HOST ) ); ?></dd>
				</div>
				<div>
					<dt class="respok-k"><?php esc_html_e( 'RESPOK dashboard', 'respok-woocommerce' ); ?></dt>
					<dd class="respok-v">
						<a href="<?php echo esc_url( PairingService::app_base_url() ); ?>" target="_blank" rel="noopener noreferrer">
							<?php echo esc_html( PairingService::app_base_url() ); ?>
						</a>
					</dd>
				</div>
			</dl>

			<div class="respok-actions">
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<?php wp_nonce_field( 'respok_wc_test_connection' ); ?>
					<input type="hidden" name="action" value="respok_wc_test_connection" />
					<button type="submit" class="respok-btn"><?php esc_html_e( 'Test connection', 'respok-woocommerce' ); ?></button>
				</form>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<?php wp_nonce_field( 'respok_wc_sync_now' ); ?>
					<input type="hidden" name="action" value="respok_wc_sync_now" />
					<button type="submit" class="respok-btn"><?php esc_html_e( 'Sync products', 'respok-woocommerce' ); ?></button>
				</form>
				<?php if ( Capabilities::current_user_can_connect() ) : ?>
				<span class="respok-spacer"></span>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" onsubmit="return confirm('<?php echo esc_js( __( 'Disconnect this store from RESPOK?', 'respok-woocommerce' ) ); ?>');">
					<?php wp_nonce_field( 'respok_wc_disconnect' ); ?>
					<input type="hidden" name="action" value="respok_wc_disconnect" />
					<button type="submit" class="respok-btn respok-btn-danger"><?php esc_html_e( 'Disconnect', 'respok-woocommerce' ); ?></button>
				</form>
				<?php endif; ?>
			</div>
		</div>

		<div class="respok-card">
			<h2><?php esc_html_e( 'Chat widget', 'respok-woocommerce' ); ?></h2>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<?php wp_nonce_field( 'respok_wc_save_settings' ); ?>
				<input type="hidden" name="action" value="respok_wc_save_settings" />
				<label class="respok-toggle">
					<input type="checkbox" name="auto_widget" value="1" <?php checked( ! empty( $settings['auto_widget'] ) ); ?> />
					<span>
						<?php esc_html_e( 'Show the chat widget in the store', 'respok-woocommerce' ); ?>
						<span class="respok-help"><?php esc_html_e( 'Configure the widget in the RESPOK dashboard.', 'respok-woocommerce' ); ?></span>
					</span>
				</label>
				<div class="respok-actions">
					<button type="submit" class="respok-btn"><?php esc_html_e( 'Save', 'respok-woocommerce' ); ?></button>
				</div>
			</form>
		</div>

		<?php DiagnosticsPage::render( $credential, $settings ); ?>

		<p class="respok-foot">
			<?php esc_html_e( 'Manage products, prices, stock, orders, permissions, and sync in RESPOK under Integrations > Store.', 'respok-woocommerce' ); ?>
		</p>
		<?php
	}
}
