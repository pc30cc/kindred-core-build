<?php
namespace Respok\WooCommerce;

use Respok\WooCommerce\Admin\SettingsPage;
use Respok\WooCommerce\Admin\ConnectionController;
use Respok\WooCommerce\Admin\PluginsScreen;
use Respok\WooCommerce\Events\WooEventSubscriber;
use Respok\WooCommerce\Events\EventDelivery;
use Respok\WooCommerce\Rest\ProductController;
use Respok\WooCommerce\Rest\Router;
use Respok\WooCommerce\Support\Updater;
use Respok\WooCommerce\Support\WidgetLoader;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Composition root. Registers every hook the plugin owns. Runs ONLY after
 * respok-woocommerce.php has confirmed the environment (PHP/WP/WooCommerce
 * versions) — this class assumes WooCommerce classes exist.
 */
final class Plugin {

	private static ?self $instance = null;

	public static function instance(): self {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {}

	public function boot(): void {
		( new SettingsPage() )->register();
		( new ConnectionController() )->register();
		( new PluginsScreen() )->register();
		( new Router() )->register();
		ProductController::register_query_filters();
		( new WooEventSubscriber() )->register();
		( new EventDelivery() )->register();
		( new WidgetLoader() )->register();
		( new Updater() )->register();
	}
}
