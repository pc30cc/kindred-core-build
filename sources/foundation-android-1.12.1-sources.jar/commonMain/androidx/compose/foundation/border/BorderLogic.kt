/*
 * Copyright 2026 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.compose.foundation.border

import androidx.compose.runtime.annotation.RememberInComposition
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.isSimple
import androidx.compose.ui.geometry.minDimension
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.ClipOp
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathOperation
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.layer.CompositingStrategy.Companion.Offscreen
import androidx.compose.ui.graphics.layer.GraphicsLayer
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.unit.IntSize
import kotlin.math.ceil
import kotlin.math.max

/**
 * Border drawing and caching logic based on androidx.compose.foundation.border, moved out of a draw
 * node and with support for efficient width animation. To draw multiple different borders
 * concurrently, create a new instance of this class for each border. Each instance must be
 * remembered across recompositions and cached across draw phases.
 *
 * This draws an 'inner' border, so the outer edge of the border lines up with the [Outline]
 * boundary.
 */
// TODO(b/487676841): Unify border forks for Glimmer / Style & Modifier.Border
@Suppress("NOTHING_TO_INLINE")
internal class BorderLogic @RememberInComposition constructor() {
    // BorderPath object that is lazily allocated depending on the type of shape
    // This object is only used for generic shapes and rounded rectangles with different corner
    // radius sizes.
    private var borderPath: Path? = null

    private var borderWidth: (() -> Float)? = null
    private var lastBrush: Brush? = null
    private var lastOutline: Outline? = null
    // Cached draw border that will be reused if the above parameters don't change
    private var drawBorder: (DrawScope.() -> Unit)? = null

    /**
     * Draws a border with the given parameters. If the provided parameters are the same, previous
     * drawing logic can be re-used for successive draws. As a result drawing multiple borders
     * concurrently should use multiple instances of [BorderLogic], to allow each individual border
     * to be cached through draw invalidations if the parameters are the same.
     *
     * @param drawScope the [DrawScope]
     * @param width The width of the border. Note that [width] can be updated without invalidating
     *   cached logic, as it is evaluated during drawing.
     * @param brush The [Brush] to paint the border with.
     * @param graphicsLayerProvider Provides a [GraphicsLayer] that will sometimes be created for
     *   caching if necessary. The caller is responsible for its lifecycle.
     * @param outline The [Outline] of the border.
     * @param offset The [Offset] to apply to the border.
     */
    internal fun drawBorder(
        drawScope: DrawScope,
        width: () -> Float,
        brush: Brush,
        graphicsLayerProvider: () -> GraphicsLayer,
        outline: Outline,
        offset: Offset = Offset.Zero,
    ): Unit =
        with(drawScope) {
            // Changes in border width can be dynamically read during draw, no need to re-create
            // drawing lambdas
            borderWidth = width
            // We accept an outline here instead of a shape,
            // since shapes can be observable and create different outlines over time. This also
            // means we can avoid creating multiple outlines for cases where we want to draw
            // multiple borders for the same shape - the caller can create one outline and provide
            // it to different BorderLogic instances. The alternative would be to `observeReads {
            // shape.createOutline(...) }` but it is harder to encapsulate the logic for that inside
            // this class, and `observeReads` adds notable cost.
            if (brush != lastBrush || outline != lastOutline || drawBorder == null) {
                lastBrush = brush
                lastOutline = outline

                drawBorder =
                    when (outline) {
                        is Outline.Generic ->
                            createDrawGenericBorder(brush, graphicsLayerProvider, outline)

                        is Outline.Rounded -> createDrawRoundRectBorder(brush, outline)

                        is Outline.Rectangle -> createDrawRectBorder(brush, outline)
                    }
            }
            if (offset == Offset.Zero) {
                drawBorder!!()
            } else {
                translate(offset.x, offset.y) { drawBorder!!() }
            }
        }

    private inline fun strokeWidthPx(): Float = borderWidth!!.invoke().coerceAtLeast(0f)

    /**
     * Border implementation for generic paths. Note it is possible to be given paths that do not
     * make sense in the context of a border (ex. a figure 8 path or a non-enclosed shape) We do not
     * handle that here as we expect developers to give us enclosed, non-overlapping paths.
     */
    private fun createDrawGenericBorder(
        brush: Brush,
        graphicsLayerProvider: () -> GraphicsLayer,
        outline: Outline.Generic,
    ): DrawScope.() -> Unit {
        val pathBounds = outline.path.getBounds()
        val pathMinDimension = pathBounds.minDimension
        // Create a mask path that includes a rectangle with the original path cut out of it.
        val maskPath =
            obtainPath().apply {
                reset()
                addRect(pathBounds)
                op(this, outline.path, PathOperation.Difference)
            }

        val pathBoundsSize =
            IntSize(ceil(pathBounds.width).toInt(), ceil(pathBounds.height).toInt())

        return {
            val strokeWidth = strokeWidthPx()
            val fillArea = (strokeWidth * 2) > pathMinDimension
            if (fillArea) {
                drawPath(outline.path, brush = brush)
            } else {
                val layer = graphicsLayerProvider()
                layer.compositingStrategy = Offscreen
                translate(pathBounds.left, pathBounds.top) {
                    layer.record(pathBoundsSize) {
                        // Paths can have offsets, so translate to keep the drawn path
                        // within the bounds of the mask
                        translate(-pathBounds.left, -pathBounds.top) {
                            // Draw the path with a stroke width twice the provided value.
                            // Because strokes are centered, this will draw both and inner and
                            // outer stroke with the desired stroke width
                            drawPath(
                                path = outline.path,
                                brush = brush,
                                style = Stroke(strokeWidth * 2),
                            )

                            // Scale the canvas slightly to cover the background that may be
                            // visible
                            // after clearing the outer stroke
                            scale((size.width + 1) / size.width, (size.height + 1) / size.height) {
                                // Remove the outer stroke by clearing the inverted mask path
                                drawPath(
                                    path = maskPath,
                                    brush = brush,
                                    blendMode = BlendMode.Clear,
                                )
                            }
                        }
                    }
                    drawLayer(layer)
                }
            }
        }
    }

    private fun obtainPath(): Path = borderPath ?: Path().also { borderPath = it }

    /** Border implementation for simple rounded rects and those with different corner radii */
    private fun createDrawRoundRectBorder(
        brush: Brush,
        outline: Outline.Rounded,
    ): DrawScope.() -> Unit {
        val roundRect = outline.roundRect
        if (roundRect.isSimple) {
            return {
                val strokeWidth = strokeWidthPx()
                val halfStroke = strokeWidth / 2
                val fillArea = (strokeWidth * 2) > roundRect.minDimension
                val cornerRadius = roundRect.topLeftCornerRadius
                val borderStroke = Stroke(strokeWidth)
                when {
                    fillArea -> {
                        // If the drawing area is smaller than the stroke being drawn
                        // drawn all around it just draw a filled in rounded rect
                        drawRoundRect(
                            brush,
                            topLeft = Offset(roundRect.left, roundRect.top),
                            size = Size(roundRect.width, roundRect.height),
                            cornerRadius = cornerRadius,
                        )
                    }
                    cornerRadius.x < halfStroke -> {
                        // If the corner radius is smaller than half of the stroke width
                        // then the interior curvature of the stroke will be a sharp edge
                        // In this case just draw a normal filled in rounded rect with the
                        // desired corner radius but clipping out the interior rectangle
                        clipRect(
                            roundRect.left + strokeWidth,
                            roundRect.top + strokeWidth,
                            roundRect.right - strokeWidth,
                            roundRect.bottom - strokeWidth,
                            clipOp = ClipOp.Difference,
                        ) {
                            drawRoundRect(
                                brush,
                                topLeft = Offset(roundRect.left, roundRect.top),
                                size = Size(roundRect.width, roundRect.height),
                                cornerRadius = cornerRadius,
                            )
                        }
                    }
                    else -> {
                        // Otherwise draw a stroked rounded rect with the corner radius
                        // shrunk by half of the stroke width. This will ensure that the
                        // outer curvature of the rounded rectangle will have the desired
                        // corner radius.
                        drawRoundRect(
                            brush = brush,
                            topLeft =
                                Offset(roundRect.left + halfStroke, roundRect.top + halfStroke),
                            size =
                                Size(roundRect.width - strokeWidth, roundRect.height - strokeWidth),
                            cornerRadius = cornerRadius.shrink(halfStroke),
                            style = borderStroke,
                        )
                    }
                }
            }
        } else {
            val path = obtainPath()
            var lastStrokeWidth = Float.NaN
            var roundedRectPath: Path? = null

            return {
                val strokeWidthPx = strokeWidthPx()
                val fillArea = (strokeWidthPx * 2) > roundRect.minDimension
                if (lastStrokeWidth != strokeWidthPx) {
                    roundedRectPath = createRoundRectPath(path, roundRect, strokeWidthPx, fillArea)
                    lastStrokeWidth = strokeWidthPx
                }
                drawPath(roundedRectPath!!, brush = brush)
            }
        }
    }

    /** Border implementation for rectangular borders */
    private fun createDrawRectBorder(
        brush: Brush,
        outline: Outline.Rectangle,
    ): DrawScope.() -> Unit {
        val rect = outline.rect
        return {
            val strokeWidthPx = strokeWidthPx()
            val fillArea = (strokeWidthPx * 2) > rect.minDimension
            // If we are drawing a rectangular stroke, just offset it by half the stroke
            // width as strokes are always drawn centered on their geometry.
            // If the border is larger than the drawing area, just fill the area with a
            // solid rectangle
            val rectTopLeft =
                if (fillArea) {
                    rect.topLeft
                } else {
                    Offset(rect.left + strokeWidthPx / 2, rect.top + strokeWidthPx / 2)
                }
            val rectSize =
                if (fillArea) {
                    rect.size
                } else {
                    Size(rect.width - strokeWidthPx, rect.height - strokeWidthPx)
                }
            val style = if (fillArea) Fill else Stroke(strokeWidthPx)
            drawRect(brush = brush, topLeft = rectTopLeft, size = rectSize, style = style)
        }
    }
}

/**
 * Helper method that creates a round rect with the inner region removed by the given stroke width
 */
private fun createRoundRectPath(
    targetPath: Path,
    roundedRect: RoundRect,
    strokeWidth: Float,
    fillArea: Boolean,
): Path =
    targetPath.apply {
        reset()
        addRoundRect(roundedRect)
        if (!fillArea) {
            val insetPath =
                Path().apply { addRoundRect(createInsetRoundedRect(strokeWidth, roundedRect)) }
            op(this, insetPath, PathOperation.Difference)
        }
    }

private fun createInsetRoundedRect(widthPx: Float, roundedRect: RoundRect) =
    RoundRect(
        left = roundedRect.left + widthPx,
        top = roundedRect.top + widthPx,
        right = roundedRect.right - widthPx,
        bottom = roundedRect.bottom - widthPx,
        topLeftCornerRadius = roundedRect.topLeftCornerRadius.shrink(widthPx),
        topRightCornerRadius = roundedRect.topRightCornerRadius.shrink(widthPx),
        bottomLeftCornerRadius = roundedRect.bottomLeftCornerRadius.shrink(widthPx),
        bottomRightCornerRadius = roundedRect.bottomRightCornerRadius.shrink(widthPx),
    )

/**
 * Helper method to shrink the corner radius by the given value, clamping to 0 if the resultant
 * corner radius would be negative
 */
private fun CornerRadius.shrink(value: Float): CornerRadius =
    CornerRadius(max(0f, this.x - value), max(0f, this.y - value))
